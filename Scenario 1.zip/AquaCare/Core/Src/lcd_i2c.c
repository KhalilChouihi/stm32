#include "lcd_i2c.h"
#include "stm32f4xx_hal.h"

extern I2C_HandleTypeDef hi2c1;

#define LCD_ADDR (0x27 << 1)   // PB0 détecté → adresse = 0x27
#define LCD_BACKLIGHT 0x08

void lcd_send_cmd(uint8_t cmd)
{
    uint8_t data_u = (cmd & 0xF0);
    uint8_t data_l = ((cmd << 4) & 0xF0);
    uint8_t data_t[4];

    data_t[0] = data_u | LCD_BACKLIGHT | 0x04;
    data_t[1] = data_u | LCD_BACKLIGHT;
    data_t[2] = data_l | LCD_BACKLIGHT | 0x04;
    data_t[3] = data_l | LCD_BACKLIGHT;

    HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, data_t, 4, 10);
}

void lcd_send_data(uint8_t data)
{
    uint8_t data_u = (data & 0xF0);
    uint8_t data_l = ((data << 4) & 0xF0);
    uint8_t data_t[4];

    data_t[0] = data_u | LCD_BACKLIGHT | 0x05;
    data_t[1] = data_u | LCD_BACKLIGHT;
    data_t[2] = data_l | LCD_BACKLIGHT | 0x05;
    data_t[3] = data_l | LCD_BACKLIGHT;

    HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, data_t, 4, 10);
}

void lcd_clear(void)
{
    lcd_send_cmd(0x01);
    HAL_Delay(2);
}

void lcd_put_cur(int row, int col)
{
    uint8_t pos = (row == 0) ? (0x80 + col) : (0xC0 + col);
    lcd_send_cmd(pos);
}

void lcd_init(I2C_HandleTypeDef *hi2c)
{
    HAL_Delay(50);

    lcd_send_cmd(0x30);
    HAL_Delay(5);

    lcd_send_cmd(0x30);
    HAL_Delay(1);

    lcd_send_cmd(0x30);
    HAL_Delay(10);

    lcd_send_cmd(0x20);  // 4-bit mode

    lcd_send_cmd(0x28);  // 2 lines
    lcd_send_cmd(0x0C);  // display on, no cursor
    lcd_send_cmd(0x06);  // auto increment
    lcd_send_cmd(0x01);  // clear
    HAL_Delay(5);
}

void lcd_send_string(char *str)
{
    while (*str)
    {
        lcd_send_data(*str++);
    }
}
